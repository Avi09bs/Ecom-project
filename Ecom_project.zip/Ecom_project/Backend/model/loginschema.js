const mongoose=require('../database/connect');

const loginSchema= mongoose.Schema(
    {
       
        name:{
            type: String,
            required: true,
            
        },
        email:{
            type: String,
            required: true,
        },
        pwd:{
            type: String,
            required: true,
        
        },}
);
const logSchema= mongoose.model('LG',loginSchema);

module.exports=logSchema;
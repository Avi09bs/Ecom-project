const express=require('express');
// const UC=require('../controller/usrcontroller.js');
const LC=require('../controller/logincontroller.js');
const UC=require('../controller/usrcntlr.js')


const route=express.Router();
const multer = require('multer');

// Set up multer for handling file uploads
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

route.get('/',(req,res)=>{
    res.send(`<h3>Product router called<h3>`);
})

route.get('/all',UC.showall);
route.get('/search',UC.finduser);
// route.post('/insert',UC.adduser);
route.post('/adduser', upload.array('images', 4), UC.adduser);
route.put('/update/:id',UC.upduser);
route.delete('/delete/:id',UC.deluser);
route.post('/login',LC.login);
route.post('/register',LC.register);

module.exports=route
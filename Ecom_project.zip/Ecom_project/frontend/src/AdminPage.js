import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './AdminPage.css';  // Import the CSS file

export default function AdminPage() {
    const [products, setProducts] = useState([]);
    const [form, setForm] = useState({
        title: '',
        description: '',
        price: '',
        rating: '',
        stock: '',
        brand: '',
        category: '',
        images: []
    });
    const [selectedProduct, setSelectedProduct] = useState(null);

    useEffect(() => {
        fetchProducts();
    }, []);

    const fetchProducts = () => {
        axios.get('http://localhost:4000/usr/all')
            .then(res => {
                setProducts(res.data.data);
            })
            .catch(err => {
                console.error(err);
            });
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setForm({
            ...form,
            [name]: value
        });
    };

    const handleFileChange = (e) => {
        setForm({
            ...form,
            images: e.target.files
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const formData = new FormData();
        for (let key in form) {
            if (key === 'images') {
                for (let file of form[key]) {
                    formData.append('images', file);
                }
            } else {
                formData.append(key, form[key]);
            }
        }

        if (selectedProduct) {
            axios.put(`http://localhost:4000/usr/update/${selectedProduct._id}`, formData)
                .then(res => {
                    console.log(res.data);
                    fetchProducts();
                    setSelectedProduct(null);
                    setForm({
                        title: '',
                        description: '',
                        price: '',
                        rating: '',
                        stock: '',
                        brand: '',
                        category: '',
                        images: []
                    });
                })
                .catch(err => {
                    console.error(err);
                });
        } else {
            axios.post('http://localhost:4000/usr/adduser', formData)
                .then(res => {
                    console.log(res.data);
                    fetchProducts();
                    setForm({
                        title: '',
                        description: '',
                        price: '',
                        rating: '',
                        stock: '',
                        brand: '',
                        category: '',
                        images: []
                    });
                })
                .catch(err => {
                    console.error(err);
                });
        }
    };

    const handleDelete = (id) => {
        axios.delete(`http://localhost:4000/usr/delete/${id}`)
            .then(res => {
                console.log(res.data);
                fetchProducts();
            })
            .catch(err => {
                console.error(err);
            });
    };

    const handleEdit = (product) => {
        setSelectedProduct(product);
        setForm({
            title: product.title,
            description: product.description,
            price: product.price,
            rating: product.rating,
            stock: product.stock,
            brand: product.brand,
            category: product.category,
            images: [] 
        });
    };

    return (
        <div className="container">
            <div className="products-section">
                <h2>Products</h2>
                <ul>
                    {products.map(product => (
                        <li key={product._id}>
                            <h3>{product.title}</h3>
                            <p>{product.description}</p>
                            <p>Price: {product.price}</p>
                            <p>Rating: {product.rating}</p>
                            <p>Stock: {product.stock}</p>
                            <p>Brand: {product.brand}</p>
                            <p>Category: {product.category}</p>
                            {product.images && product.images.map((img, index) => (
                                <img key={index} src={`data:image/jpeg;base64,${img}`} alt={product.title} />
                            ))}
                            <button className="edit" onClick={() => handleEdit(product)}>Edit</button>
                            <button className="delete" onClick={() => handleDelete(product._id)}>Delete</button>
                        </li>
                    ))}
                </ul>
            </div>
            <div className="form-section">
                <h1>Admin Page</h1>
                <form onSubmit={handleSubmit}>
                    <input type="text" name="title" placeholder="Title" value={form.title} onChange={handleInputChange} required />
                    <input type="text" name="description" placeholder="Description" value={form.description} onChange={handleInputChange} required />
                    <input type="number" name="price" placeholder="Price" value={form.price} onChange={handleInputChange} required />
                    <input type="number" name="rating" placeholder="Rating" value={form.rating} onChange={handleInputChange} required />
                    <input type="text" name="stock" placeholder="Stock" value={form.stock} onChange={handleInputChange} required />
                    <input type="text" name="brand" placeholder="Brand" value={form.brand} onChange={handleInputChange} required />
                    <input type="text" name="category" placeholder="Category" value={form.category} onChange={handleInputChange} required />
                    <input type="file" multiple onChange={handleFileChange} />
                    <button type="submit">{selectedProduct ? 'Update Product' : 'Add Product'}</button>
                </form>
            </div>
        </div>
    );
}

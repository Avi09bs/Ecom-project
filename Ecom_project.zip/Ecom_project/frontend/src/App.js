import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './Login';
import Register from './Register';
import UserPage from './UserPage';
import PrivateRoute from './Privateroute';
import AdminPage from './AdminPage';
import PaymentPage from './PaymentPage';

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/admin" element={<AdminPage/>}/>
        <Route path="/" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/userpage" element={
          <PrivateRoute>
            <UserPage />
          </PrivateRoute>
        } />
        <Route path="/payment" element={
          <PrivateRoute>
            <PaymentPage />
          </PrivateRoute>
        } />
      </Routes>
    </Router>
  );
};

export default App;



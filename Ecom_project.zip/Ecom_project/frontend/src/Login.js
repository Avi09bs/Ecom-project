import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Login.css'; 

const Login = () => {
    const [formData, setFormData] = useState({
        email: '',
        pwd: ''
    });

    const navigate = useNavigate();

    const handleChange = e => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async e => {
        e.preventDefault();
        try {
            const response = await axios.post('http://localhost:4000/usr/login', formData);
            console.log(response.data);
            alert('Login successful');

            localStorage.setItem('authToken', response.data.token);

            navigate('/userpage');
        } catch (error) {
            alert('Login failed', error);
        }
    };

    return (
        <div className="login-container">
            <h2>Login</h2>
            <form className="login-form" onSubmit={handleSubmit}>
                <div className="form-group">
                    <label>Email:</label>
                    <input type="email" name="email" value={formData.email} onChange={handleChange} required />
                </div>
                <div className="form-group">
                    <label>Password:</label>
                    <input type="password" name="pwd" value={formData.pwd} onChange={handleChange} required />
                </div>
                <button className="login-button" type="submit">Login</button>
                <a href="/register">
                    <button className="register-button" type="button">Register</button>
                </a>
            </form>
        </div>
    );
};

export default Login;


import React, { useState } from 'react';
import './PaymentPage.css';

export default function PaymentPage() {
    const [name, setName] = useState('');
    const [cardNumber, setCardNumber] = useState('');
    const [expiryDate, setExpiryDate] = useState('');
    const [cvv, setCvv] = useState('');

    const handlePayment = (e) => {
        e.preventDefault();
        // Implement the payment processing logic here
        console.log('Payment details:', { name, cardNumber, expiryDate, cvv });
        alert('Payment Successful!');
        window.location.href = '/userpage'; // Redirect to home page after payment
    };

    return (
        <div className="payment-container">
            <h2>Payment Page</h2>
            <form onSubmit={handlePayment} className="payment-form">
                <div className="form-group">
                    <label>Name on Card</label>
                    <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required
                    />
                </div>
                <div className="form-group">
                    <label>Card Number</label>
                    <input
                        type="text"
                        value={cardNumber}
                        onChange={(e) => setCardNumber(e.target.value)}
                        required
                    />
                </div>
                <div className="form-group">
                    <label>Expiry Date</label>
                    <input
                        type="month"
                        value={expiryDate}
                        onChange={(e) => setExpiryDate(e.target.value)}
                        required
                    />
                </div>
                <div className="form-group">
                    <label>CVV</label>
                    <input
                        type="number"
                        value={cvv}
                        onChange={(e) => setCvv(e.target.value)}
                        required
                        min="100"
                        max="9999"
                    />
                </div>
                <button type="submit" className="payment-button">Submit Payment</button>
            </form>
        </div>
    );
}

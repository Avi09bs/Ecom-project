import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './UserPage.css'; 

export default function UserPage() {
    const [info, setInfo] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [cart, setCart] = useState([]);
    const [addedProduct, setAddedProduct] = useState(null);

    useEffect(() => {
        axios.get('http://localhost:4000/usr/all')
            .then((res) => {
                console.log(res.data.data);
                setInfo(res.data.data);
            })
            .catch((err) => {
                console.log(err);
            });
    }, []);

    const searchProducts = () => {
        axios.get(`http://localhost:4000/usr/search?title=${searchTerm}`)
            .then((res) => {
                setInfo(res.data.info);
            })
            .catch((err) => {
                console.log(err);
            });
    };

    const addToCart = (product) => {
        setCart([...cart, product]);
        setAddedProduct(product);
    };

    const removeFromCart = (product) => {
        setCart(cart.filter(item => item._id !== product._id));
    };

    const logout = () => {
        // Clear any authentication tokens or session information
        localStorage.removeItem('authToken'); // Example: clearing a token from localStorage
        window.location.href = '/'; // Redirect to the login page
    };

    const proceedToPayment = () => {
        window.location.href = '/Payment'; // Redirect to the payment page
    };

    const totalQuantity = cart.length;
    const totalPrice = cart.reduce((total, product) => total + product.price, 0);

    return (
        <div className="userpage-container">
            <div className="header">
                <button onClick={logout} className="logout-button">Logout</button>
            </div>
            <div className="search-bar">
                <input
                    type="text"
                    placeholder="Search by title"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
                <button onClick={searchProducts}>Search</button>
            </div>
            <div className="product-list">
                {info.map((val) => (
                    <div key={val._id} className="product-card">
                        <h2>{val.title}</h2>
                        <img src={val.images[0]} alt={val.title} className="product-image" />
                        <p>{val.description}</p>
                        <p>Price: ${val.price}</p>
                        <p>Rating: {val.rating}</p>
                        <p>Stock: {val.stock}</p>
                        <p>Brand: {val.brand}</p>
                        <p>Category: {val.category}</p>
                        <button onClick={() => addToCart(val)}>Add to Cart</button>
                        {addedProduct?._id === val._id && <span className="added-notice"> - Added to cart!</span>}
                    </div>
                ))}
            </div>
            <div className="cart-container">
                <h2>Cart</h2>
                {cart.length === 0 ? (
                    <p>Your cart is empty</p>
                ) : (
                    <div>
                        <ul>
                            {cart.map((item) => (
                                <li key={item._id} className="cart-item">
                                    {item.title}
                                    <button onClick={() => removeFromCart(item)}>Remove from Cart</button>
                                </li>
                            ))}
                        </ul>
                        <div className="cart-summary">
                            <h3>Total Quantity: {totalQuantity}</h3>
                            <h3>Total Price: ${totalPrice.toFixed(2)}</h3>
                        </div>
                        <button onClick={proceedToPayment} className="payment-button">Proceed to Payment</button>
                    </div>
                )}
            </div>
        </div>
    );
}


